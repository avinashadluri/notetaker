import { createStyles, makeStyles, Theme } from "@material-ui/core";
import React from 'react';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';

const useStyles = makeStyles((theme: Theme) =>
    createStyles({
        root: {
            display: "flex",
            flexDirection: "column"
        }
    })
);

interface Props {
    tags: string;
    handleTagsChange: (tags: string) => void;
}

export const Tags: React.FC<Props> = ({ tags, handleTagsChange }) => {
    const classes = useStyles();
    const categories = [
        'Productivity',
        'Health',
        'Fitness',
        'Family',
        'Money',
        'Goals',
        'Lifestyle',
        'Work',
        'Social',
    ];
    let selectedCategories = tags ? tags.split(',') : [];

    const onTagsChange = (event: any, values: any) => {
        const stringifiedValue = Array.prototype.map.call(values, s => s).toString();
        handleTagsChange(stringifiedValue)
    }

    return (
        <div className={classes.root}>
            <Autocomplete
                multiple
                id="notes-tags"
                options={categories}
                filterSelectedOptions
                onChange={onTagsChange}
                value={selectedCategories}
                renderInput={params => (
                    <TextField
                        {...params}
                        label="Tags"
                    />
                )}
            />
        </div>
    );
}