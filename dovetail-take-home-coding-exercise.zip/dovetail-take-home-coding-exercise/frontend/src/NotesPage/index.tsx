import { useQuery } from "@apollo/react-hooks";
import { createStyles, makeStyles, Theme, Typography } from "@material-ui/core";
import { gql } from "apollo-boost";
import React from "react";
import { graphql } from "../types";
import { nonNullable } from "../util";
import { NotePreview } from "./NotePreview";
import { useClientNoteOrder } from "./useClientNoteOrder";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import RootRef from "@material-ui/core/RootRef";
import {
  List,
  ListItem,
} from "@material-ui/core";

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      margin: theme.spacing(3, 0)
    }
  })
);

const NOTES_QUERY = gql`
  query NotesQuery {
    notes {
      id
      title
    }
  }
`;

const getItemStyle = (isDragging: any, draggableStyle: any) => ({
  ...draggableStyle,

  ...(isDragging && {
    background: "rgb(235,235,235)"
  })
});

export const NotesPage: React.FC = () => {
  const classes = useStyles();
  const { data } = useQuery<graphql.NotesQuery>(NOTES_QUERY);
  const { orderedNoteIds, updateStorage } = useClientNoteOrder(
    data && data.notes.map(n => n.id)
  );

  const onDragComplete = (result: any) => {
    if (!result.destination) {
      return;
    }
    console.log(orderedNoteIds);

    const neworderedNoteIds = orderedNoteIds && Array.from(orderedNoteIds);
    const removed = neworderedNoteIds && neworderedNoteIds.splice(result.source.index, 1);
    console.log('removed', removed);
    console.log('result.source.index', result.source.index);
    console.log('result.destination.index', result.destination.index);
    const output = (removed !== undefined && neworderedNoteIds) && neworderedNoteIds.splice(result.destination.index, 0, removed[0]);

    console.log('done');
    console.log('before', neworderedNoteIds);
    console.log(removed);
    console.log(output);
    console.log('after', neworderedNoteIds);
    updateStorage(neworderedNoteIds);
  }

  if (data === undefined || orderedNoteIds === undefined) {
    return null;
  }

  const notesInOrder = orderedNoteIds
    .map(noteId => data.notes.find(n => n.id === noteId))
    .filter(nonNullable);

  return (
    <div className={classes.root}>
      <Typography variant="h3">All Notes</Typography>
      <DragDropContext onDragEnd={onDragComplete}>
        <Droppable droppableId="droppable">
          {(provided, snapshot) => (
            <RootRef rootRef={provided.innerRef}>
              <List>
                {notesInOrder.map((item, index) => (
                  <Draggable key={item.id} draggableId={item.id} index={index}>
                    {(provided, snapshot) => (
                      <ListItem
                        ContainerComponent="div"
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        style={getItemStyle(
                          snapshot.isDragging,
                          provided.draggableProps.style
                        )}
                      >
                        <NotePreview
                          id={item.id}
                          key={item.id}
                          title={item.title}
                        />
                      </ListItem>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}

              </List>
            </RootRef>
          )}
        </Droppable>
      </DragDropContext>
    </div >
  );
};
