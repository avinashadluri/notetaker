import { useMutation } from "@apollo/react-hooks";
import {
  createStyles,
  makeStyles,
  Paper,
  TextField,
  Theme,
} from "@material-ui/core";
import Typography from "@material-ui/core/Typography";
import gql from "graphql-tag";
import React, { useCallback } from "react";
import { graphql } from "./types";
import { Tags } from "./Tags";

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      padding: theme.spacing(3, 2),
      margin: theme.spacing(3, 0)
    },
    input: {
      margin: theme.spacing(3, 0)
    },
    tag: {
      margin: theme.spacing(0.5)
    }
  })
);

interface Props {
  id: string;
  title: string;
  content: string;
  tags: string;
}

const NOTE_TITLE_MUTATION = gql`
  mutation NoteTitleMutation($id: ID!, $title: String!) {
    updateNoteTitle(id: $id, title: $title) {
      id
      title
      content
      tags
    }
  }
`;

const NOTE_CONTENT_MUTATION = gql`
  mutation NoteContentMutation($id: ID!, $content: String!) {
    updateNoteContent(id: $id, content: $content) {
      id
      title
      content
      tags
    }
  }
`;

const NOTE_TAGS_MUTATION = gql`
  mutation NoteContentMutation($id: ID!, $tags: String!) {
    updateNoteTags(id: $id, tags: $tags) {
      id
      title
      content
      tags
    }
  }
`;

export const Note: React.FC<Props> = ({ id, title, content, tags }) => {
  const classes = useStyles();
  const [updateNoteTitleMutation] = useMutation<
    graphql.NoteTitleMutation,
    graphql.NoteTitleMutationVariables
  >(NOTE_TITLE_MUTATION);
  const [updateNoteContentMutation] = useMutation<
    graphql.NoteContentMutation,
    graphql.NoteContentMutationVariables
  >(NOTE_CONTENT_MUTATION);
  const [updateNoteTagsMutation] = useMutation<
    graphql.NoteTagsMutation,
    graphql.NoteTagsMutationVariables
  >(NOTE_TAGS_MUTATION);

  const handleTitleChange = useCallback(
    async e => {
      const title = e.target.value;
      await updateNoteTitleMutation({
        variables: {
          id,
          title
        }
      });
    },
    [id, updateNoteTitleMutation]
  );

  const handleContentChange = useCallback(
    async e => {
      const content = e.target.value;
      await updateNoteContentMutation({
        variables: {
          id,
          content
        }
      });
    },
    [id, updateNoteContentMutation]
  );

  const handleTagsChange = useCallback(
    async tags => {
      await updateNoteTagsMutation({
        variables: {
          id,
          tags
        }
      });
    },
    [id, updateNoteTagsMutation]
  );

  return (
    <Paper className={classes.root}>
      <Typography variant="h3">Note</Typography>
      <TextField
        label={"Title"}
        className={classes.input}
        defaultValue={title}
        onBlur={handleTitleChange}
        fullWidth
      />
      <TextField
        label={"Content"}
        className={classes.input}
        defaultValue={content}
        onBlur={handleContentChange}
        fullWidth
        multiline
      />

      <Tags tags={tags} handleTagsChange={handleTagsChange} />
    </Paper>
  );
};
