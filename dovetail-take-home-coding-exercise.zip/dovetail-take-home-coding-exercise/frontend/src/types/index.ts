import * as graphql from "./graphql";
export { graphql };
